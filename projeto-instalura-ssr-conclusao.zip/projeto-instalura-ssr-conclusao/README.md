# instalura-ssr [![NPM version][npm-image]][npm-url] [![Build Status][travis-image]][travis-url] [![Dependency Status][daviddm-image]][daviddm-url]
> 

## Installation

```sh
$ npm install --save instalura-ssr
```

## Usage

```js
var instaluraSsr = require('instalura-ssr');

instaluraSsr('Rainbow');
```
## License

Apache-2.0 © []()


[npm-image]: https://badge.fury.io/js/instalura-ssr.svg
[npm-url]: https://npmjs.org/package/instalura-ssr
[travis-image]: https://travis-ci.org//instalura-ssr.svg?branch=master
[travis-url]: https://travis-ci.org//instalura-ssr
[daviddm-image]: https://david-dm.org//instalura-ssr.svg?theme=shields.io
[daviddm-url]: https://david-dm.org//instalura-ssr
