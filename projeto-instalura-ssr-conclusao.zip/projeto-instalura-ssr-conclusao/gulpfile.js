require("electrode-archetype-react-app")();
